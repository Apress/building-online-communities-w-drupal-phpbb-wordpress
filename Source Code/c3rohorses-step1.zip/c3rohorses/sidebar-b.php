  <div id="sidebar-b">
    <?php get_calendar(); ?>
<?php if (function_exists('_rssLinkList')) : ?>
    <h2><?php _e('Del.icio.us Links'); ?></h2>
    <ul class="sidebar-b-sidelists">
      <?php _rssLinkList(array("rss_feed_url"=>
       "http://del.icio.us/rss/tag/wordpress+tools",
       "show_description"=>FALSE,
       "num_items"=>10)); ?>
    </ul>
<?php endif; ?>
<?php if (function_exists('c2c_get_recent_comments')) : ?>
    <h2><?php _e('Recent Comments'); ?></h2>
    <ul  class="sidebar-b-sidelists">
      <?php c2c_get_recent_comments(5,
      "<li>%comment_author% on <a href=\"%comment_url%\" "
     . "title=\"%comment_excerpt%\" >%post_title%</a></li>"); ?>
    </ul>
<?php endif; ?>
    <h2><?php _e('Contribute'); ?></h2>
    <ul class="sidebar-b-sidelists">
      <?php wp_register(); ?>

      <li><?php wp_loginout(); ?></li>
    </ul>
  </div><!-- /sidebar-b -->
