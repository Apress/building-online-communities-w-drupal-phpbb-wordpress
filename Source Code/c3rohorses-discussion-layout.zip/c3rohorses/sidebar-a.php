    <div id="sidebar-a">

    <div id="menu">
      <ul>

      <?php wp_list_pages('title_li=<h2>' . __('Pages') . '</h2>' ); ?>

      <?php get_links_list(); ?>

      <li id="archives"><h2><?php _e('Archives'); ?></h2>
        <ul>
        <?php wp_get_archives('type=monthly'); ?>
        </ul>
      </li>

      <li id="meta"><h2><?php _e('Categories'); ?></h2>
        <ul>
        <?php wp_list_cats(); ?>
        </ul>
      </li>

<?php include_once('search-form.php'); ?>

      <li id="feed"><h2><?php _e('Feed'); ?></h2>
        <ul>
        <li><a href="<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?>"><?php _e('<abbr title="Really Simple Syndication">RSS</abbr> 2.0'); ?></a></li>
        </ul>
      </li>

      </ul>

    </div>

  </div><!-- /sidebar-a -->
