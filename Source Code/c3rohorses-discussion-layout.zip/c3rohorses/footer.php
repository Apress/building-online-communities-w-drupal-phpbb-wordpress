      <div id="footer">
        <p>
          proud to be a <a href="http://www.wordpress.org" target="new">wordpress <?php bloginfo('version'); ?></a> site<br />
          c3rohorses theme by <a href="http://zed1.com/journalized/">Mike Little</a> based on c3romask by <a href="http://c3ro.com">c3ro</a>
        </p>
      </div>
