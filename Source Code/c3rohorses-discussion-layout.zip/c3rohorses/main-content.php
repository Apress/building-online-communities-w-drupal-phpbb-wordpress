      <div id="main-content" class="<?php echo $main_content_class; ?>">

        <div id="content">
        <?php if ($posts) : foreach ($posts as $post) : start_wp(); ?>

        <br />
        <h2><?php the_time('l, F jS Y') ?></h2>

        <br />
        <a href="<?php the_permalink() ?>" class="postTitle" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a>
        <br />
        <em>posted @ <?php the_time() ?> <?php edit_post_link(); ?> in</em> <strong>[</strong> <?php the_category( ' -' ) ?> <strong>]</strong>

        <div class="storycontent">
          <?php the_content(); ?>
        </div>

        <hr />
        <div class="feedback" align="right">
          <?php wp_link_pages(); ?>
          <?php comments_popup_link(__('Comments (0)'), __('Comments (1)'), __('Comments (%)')); ?>
        </div>
        <!--
        <?php trackback_rdf(); ?>
        -->

        <?php comments_template(); ?>

        <?php endforeach; else: ?>
        <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
        <?php endif; ?>
        </div>

        <div id="navigation" align="center">
          <div class="prev"><?php posts_nav_link('','','&laquo; Previous Posts') ?></div>
          <div class="next"><?php posts_nav_link('','Next Posts &raquo;','') ?></div>
        </div>

      </div><!-- /main-content -->
