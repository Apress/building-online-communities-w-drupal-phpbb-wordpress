<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head profile="http://gmpg.org/xfn/1">
	<title><?php bloginfo('name'); ?><?php wp_title(); ?></title>

	<meta name="description" content="<?php bloginfo('description'); ?>" />
	<meta name="keywords" content="<?php echo implode(',' , explode(' ', get_bloginfo('description'))); ?>" />
	<meta name="robots" content="index, follow" />
	<meta name="GOOGLEBOT" content="index, follow" />
	<meta http-equiv="expires" content="604800" />
	<meta name="MSSmartTagsPreventParsing" content="yes" />
	<meta name="geo.country" content="US" />
	<link rel="bookmark" title="<?php bloginfo('name'); ?>" href="<?php bloginfo('url'); ?>" />

	<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo('charset'); ?>" />
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />

	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />

	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_get_archives('type=monthly&format=link'); ?>
	<?php //comments_popup_script(); // off by default ?>
	<?php wp_head(); ?>
	<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats -->
</head>

<body>


<div id="wrapper">
	<div id="head"><a href="<?echo get_settings('siteurl');?>"><img src="<?echo get_template_directory_uri();?>/images/bg-head-1.jpg"  alt="<?php bloginfo('name'); ?>" /></a></div>
	<div id="container">
		<div id="pagecontent">

			<div id="left">

				<div id="content">
				<?php if ($posts) : foreach ($posts as $post) : start_wp(); ?>

				<br />
				<h2><?php the_time('l, F jS Y') ?></h2>

				<br />
				<a href="<?php the_permalink() ?>" class="postTitle" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a>
				<br />
				<i>posted @ <?php the_time() ?> <?php edit_post_link(); ?> in</i> <b>[</b> <?php the_category( ' -' ) ?> <b>]</b>

				<div class="storycontent">
					<?php the_content(); ?>
				</div>

				<hr />
				<div class="feedback" align="right">
					<?php wp_link_pages(); ?>
					<?php comments_popup_link(__('Comments (0)'), __('Comments (1)'), __('Comments (%)')); ?>
				</div>
				<!--
				<?php trackback_rdf(); ?>
				-->

				<?php comments_template(); ?>

				<?php endforeach; else: ?>
				<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
				<?php endif; ?>
				</div>

				<div class="navigation" align="center">
					<div align="left"><?php posts_nav_link('','','&laquo; Previous Posts') ?></div>
					<div align="right"><?php posts_nav_link('','Next Posts &raquo;','') ?></div>
				</div>

			</div><!-- /left -->

			<div id="center">
			<br />

				<div align="left"><?php posts_nav_link('','','&laquo; Previous Posts') ?></div>
				<div align="right"><?php posts_nav_link('','Next Posts &raquo;','') ?></div>
				<br />
				<div id="menu">
					<ul>
						<?php if (function_exists('wp_theme_switcher')) { ?>
						<li><b><?php _e('Theme Changer'); ?></b>
						<?php wp_theme_switcher('dropdown'); ?>
						</li>
						<?php } ?>

						<?php wp_list_pages('title_li=<h2>' . __('Pages') . '</h2>' ); ?>

						<?php get_links_list(); ?>

						<li id="archives"><h2><?php _e('Archives'); ?></h2>
						 	<ul>
								<?php wp_get_archives('type=monthly'); ?>
							</ul>
						</li>

						<li id="meta"><h2><?php _e('Categories'); ?></h2>
							<ul>
								<?php wp_list_cats(); ?>
							</ul>
						</li>
						<li id="search"><h2><?php _e('Search'); ?></h2>
							<form id="searchform" method="get" action="<?php echo $PHP_SELF; ?>">
								<input type="text" name="s" id="s" size="15" class="input" />
								<input type="submit" name="submit" value="<?php _e('GO'); ?>" class="button"/>
							</form>
						</li>
						<li id="feed"><h2><?php _e('Feed'); ?></h2>
							<ul>
								<li><a href="<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?>"><?php _e('<abbr title="Really Simple Syndication">RSS</abbr> 2.0'); ?></a></li>
							</ul>
						 </li>
					</ul>

				</div>

			</div><!-- /side -->

			<div id="right">

				<?php get_calendar(); ?>
				<div id="buttons">
				<ul>
					<li><a class="img" href="http://www.rantradio.com/" title="listen"><img src="<?echo get_settings('siteurl');?>/wp-content/themes/c3romask/images/b_listen.gif" width="80" height="15" border="0" alt="" /></a></li>
					<li><a class="img" href="http://www.thehungersite.com/" title="hunger"><img src="<?echo get_settings('siteurl');?>/wp-content/themes/c3romask/images/b_hunger.gif" width="80" height="15" border="0" alt="" /></a></li>
					<li><a class="img" href="http://www.eff.org/br/" title="speak"><img src="<?echo get_settings('siteurl');?>/wp-content/themes/c3romask/images/b_eff.gif" width="80" height="15" border="0" alt="" /></a></li>
					<li><a class="img" href="http://internetbrothers.com/aortal/" title="aortal"><img src="<?echo get_settings('siteurl');?>/wp-content/themes/c3romask/images/b_aortal.gif" width="80" height="15" border="0" alt="" /></a></li>
					<li><a class="img" href="http://www.spreadfirefox.com/?q=affiliates&amp;id=40035&amp;t=82" title="take back the web"><img border="0" alt="Get Firefox!" title="Get Firefox!" src="http://sfx-images.mozilla.org/affiliates/Buttons/80x15/white_1.gif"/></a></li>
					<li>
					<form action="">
						<input style="width:75px; font:bold 11px verdana, helvetica, sans-serif; color:white; background-color:#0066CC;" type="button" value="SOUL" title="Nestled into the corners and other hidden places, the web holds her treasures" onclick="window.open('http://souloftheweb.com/soul.shtml','soul','height=300,width=302,toolbar=no,menubar=no,status=no,scrollbars=no,resizable=no');" name="button" />
					</form>
					</li>
				 </ul>
				</div>

			</div><!-- /side -->

			<div id="footer">
				<p>
					proud to be a <a href="http://www.wordpress.org" target="new">wordpress <?php bloginfo('version'); ?></a> site<br />
					theme by <a href="http://c3ro.com">c3ro</a>

				</p>
			</div>

		</div><!-- /content -->
	</div><!-- /container -->

</div><!-- /wrapper -->


</body>
</html>
