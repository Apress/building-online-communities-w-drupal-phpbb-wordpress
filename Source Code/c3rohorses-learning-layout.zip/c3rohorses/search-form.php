      <li id="search"><h2><?php _e('Search'); ?></h2>
        <form id="searchform" method="get" action="<?php echo $PHP_SELF; ?>">
        <input type="text" name="s" id="s" size="15" class="input" />
        <input type="submit" name="submit" value="<?php _e('GO'); ?>" class="button"/>
        </form>
      </li>
