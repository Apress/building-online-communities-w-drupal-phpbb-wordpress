<?php
    $categories = get_the_category();
    $cat = $categories[0]->cat_ID;
    $posts = get_posts('numberposts=10&category=' . $cat);
?>

  <div id="sidebar-b">

    <h2><?php _e('Other articles'); ?></h2>
    <ul class="sidebar-b-sidelists">

    <?php
      foreach($posts as $post) :
    ?>
      <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
    <?php endforeach; ?>

    </ul>

    <h2><?php _e('Resources'); ?></h2>
    <ul class="sidebar-b-sidelists">
    <?php
      wp_get_links($cat);
    ?>

    </ul>

    <h2><?php _e('Contribute'); ?></h2>
    <ul class="sidebar-b-sidelists">
      <?php wp_register(); ?>

      <li><?php wp_loginout(); ?></li>
    </ul>
  </div><!-- /sidebar-b -->
