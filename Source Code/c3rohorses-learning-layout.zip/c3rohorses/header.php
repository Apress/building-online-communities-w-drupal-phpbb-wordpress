  <div id="head"><a href="<?echo get_settings('siteurl');?>"><img src="<?echo get_template_directory_uri();?>/images/bg-head-1.jpg" alt="<?php bloginfo('name'); ?>" /></a></div>
