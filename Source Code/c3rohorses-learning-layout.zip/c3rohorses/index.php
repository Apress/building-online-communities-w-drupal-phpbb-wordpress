<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<?php include_once('html-head.php'); ?>

<body>

<div id="wrapper">

  <?php get_header(); ?>

  <div id="container">
    <div id="pagecontent">
<?php
    if (is_single()) {
      $main_content_class = 'main-content-wide';
    } else {
      $main_content_class = 'main-content-norm';
    }

    include_once('main-content.php'); 

    if (is_single()) {
      include_once('sidebar-c.php');
    } else {
      include_once('sidebar-a.php');
      include_once('sidebar-b.php');
    }
?>
    </div><!-- /pagecontent -->
  </div><!-- /container -->

  <?php get_footer(); ?>

</div><!-- /wrapper -->

</body>
</html>
